<?php 

    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        require_once("db.php");

        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $telefono = $_POST['telefono'];
        $email = $_POST['email'];

        $query = "INSERT INTO cliente (nombre, apellido, telefono, email) VALUES('$nombre','$apellido','$telefono','$email')";
        $result = $mysql->query($query);

        if($result === TRUE){
            echo "Creado correctamente";
        }else{
            echo"Error";
        }

        $mysql->close();
    }