<?php

    $mysql = new mysqli(
        "localhost",
        "root",
        "mvrm1998",
        "android_bd"
    );

    if ($mysql->connect_error){
        die("error de conexion" . $mysql->connect_error);
    }