<?php

include 'db.php';
$idcliente=$_POST['idcliente'];

$query = "DELETE FROM cliente where idcliente = '$idcliente'";
$mysql->query($query,) OR DIE ($mysql->connect_error);
$mysql->close();