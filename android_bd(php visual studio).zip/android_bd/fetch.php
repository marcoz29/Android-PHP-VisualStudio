<?php

    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        
        require_once("db.php");

        $idcliente = $_GET['idcliente'];

        $query = "SELECT * FROM cliente WHERE idcliente = '$idcliente'";
        $result = $mysql->query($query);

        if($mysql->affected_rows > 0){
            while($row = $result->fetch_assoc()){
                $array = $row;
            }

            echo json_encode($array);
        }else{
            echo "No encontrado";
        }

        $result->close();
        $mysql->close();
    }